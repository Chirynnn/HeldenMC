# heldenpack
HeldenMC custom resource pack

Files will not be stored here, just the packaged resource pack for automatic distribution to players
